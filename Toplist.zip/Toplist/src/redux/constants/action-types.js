const ActionTypes = {
    SET_ITEMS : "SET_ITEMS",
    LOGGED : "LOGGED",
    SELECTED_ITEM : "SELECTED_ITEM",
    CREATE_ITEM : "CREATE_ITEM",
    UPDATE_ITEM : "UPDATE_ITEM",
    DELETE_ITEM : "DELETE_ITEM",
    PUSH_CLICKS : "PUSH_CLICKS",
    SHOW_CLICKS : "SHOW_CLICKS"
}
export default ActionTypes