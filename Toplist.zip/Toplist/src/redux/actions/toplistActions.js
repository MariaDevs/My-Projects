import ActionTypes from "../constants/action-types";
import axios from "axios";
import ItemList from "../../components/ItemList";



export const setItems = (items)=>{
return {
    type: ActionTypes.SET_ITEMS,
    payload: items,
}
}
export const setLogged = () => ({
    type: ActionTypes.LOGGED,
    payload: true
})

export const selectedItem = (item)=>{
    return {
        type: ActionTypes.SELECTED_ITEM,
        payload: item,
    }
    }
    export const cretateItem = (item)=>{
        return {
            type: ActionTypes.CREATE_ITEM,
            payload: item,
        }
        }
        export const updateItem = (item)=>{
            return {
                type: ActionTypes.UPDATE_ITEM,
                payload: item,
            }
            }
            export const itemDeleted = ()=>{
                return {
                    type: ActionTypes.DELETE_ITEM,
                   
                    }
                
                }
                
                
                export const deleteItem =(id)=>{
                    return function (dispatch) {
                        axios.delete('${process.env.REACT_APP_API}/${id}').then
                        ((resp)=>{console.log("resp",resp);
                        dispatch(itemDeleted)
                        dispatch(ItemList.fetchItems())
                    })
                        .catch((err)=> console.log(err))
                    }
                }
                export const addItem = (item)=>{
                    return function (dispatch) {
                        axios.post('${process.env.REACT_APP_API}',item).then
                        ((resp)=>{console.log("resp",resp);
                        dispatch(cretateItem)
                    })
                        .catch((err)=> console.log(err))
                    }
                }
                 


                           
    


       


  