import React, { useState } from "react";
import { useDispatch, useSelector} from "react-redux";
import { Box,ButtonGroup, Button,Paper,Table,TableBody,TableCell,TableContainer,TableHead,TablePagination,TableRow, TableFooter,Fab,TextField } from "@material-ui/core";
import { EditItem } from "./Edit";
import { addItem, deleteItem } from "../redux/actions/toplistActions";




   
  
  
  const ItemComponent = ()=>{
  
    
    const dispatch = useDispatch();
  
    const deleteClickHandle = (id)=>{
        
      if (window.confirm("Are you sure about deleting the item ?")){
        dispatch( deleteItem(id))       
      }  
    }
      
      const editClickHandle = (id)=>{
       
      }
      const addClickHandle = ()=> {
        
        const [state , setState] = useState({
          id:"",
          brand:"",
          offer:"",
          trackingLink:"",
          createdAt:""
        })
        const [error, setError]= useState("")
        const [id,brand,Offer,trackingLink,createdAt]= state;
      } 
        const handleInputChange = (e) =>{
          let {name,value} = e.target;
          setState({...state, [name]: value})
        }
      
       const handleSubmit = (e) =>{
        e.preventDefault();
        if(!id || !brand || !offer || !trackingLink || !createdAt)
        {
          setError("Please enter all details");
        }
        else{
          dispatch(addItem(state));
          history.push("/"); 
          setError("");
        }

      
    }
     
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(200);
  
    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
  
    const handleChangeRowsPerPage = (event) => {
      setRowsPerPage(+event.target.value);
      setPage(0);
    };

 const items = useSelector((state)=> state.allItems.items);
 console.log(items)

return(
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
        <TableContainer sx={{ maxHeight: 440 }}>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>

                  <TableCell align="center">ID</TableCell>
                  <TableCell align="center">Brand</TableCell>
                  <TableCell align="center">Offer</TableCell>
                  <TableCell align="center">Tracking Link</TableCell>
                  <TableCell align="center">Created At</TableCell>
                  <TableCell align="center">Actions</TableCell>

              </TableRow>
            </TableHead>
            <TableBody>
              {items && items.map((item) =>(

                 <TableRow hover role="checkbox" tabIndex={-1} key={item.id}>
                      
                        
                          <TableCell component="th" scope="item" align="center">
                            {item.id}
                          </TableCell>

                          <TableCell align="center">
                            {item.brand}
                          </TableCell>

                          <TableCell align="center">
                            {item.offer}
                          </TableCell>

                          <TableCell align="center">
                            {item.trackingLink}
                          </TableCell>

                          <TableCell align="center">
                          {item.createdAt}
                          </TableCell>

                          <TableCell>
                          <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        '& > *': {
          m: 1,
        },
      }}
    >
      <ButtonGroup size="small" aria-label="small button group">
      <Button style={{marginRight:"8px"}} key="edit"variant="contained" color="primary" onClick={editClickHandle}>Edit</Button>,
      <Button key="delete" variant="contained" color="secondary" onClick={()=> deleteClickHandle(item.id)}>Delete</Button>,
      
      </ButtonGroup>    
</Box>
                          </TableCell> 
                    </TableRow>
              ))};
            </TableBody>

            <TableFooter onSubmit={handleSubmit}>
            
            <TableCell align="center">
            <TextField id="IdText" label="ID" variant="outlined"  type={"number"} name="id"
            onChange={handleInputChange}/>
            </TableCell>

            <TableCell align="center">
            <TextField id="brandText" label="Brand" variant="outlined"  type={"text"} name="brand" 
            onChange={handleInputChange}/>
            </TableCell>

            <TableCell align="center">
            <TextField id="offerText" label="Offer" variant="outlined"  type={"text"} name="offer"
            onChange={handleInputChange}/>
            </TableCell>

            <TableCell align="center">
            <TextField id="trackText" label="Tracking Link" variant="outlined"  type={"text"} name="trackingLink"
            onChange={handleInputChange}/>
            </TableCell>

            <TableCell align="center">
            <TextField id="createdText" label="Created At" variant="outlined" type={"time"} name="createdAt" 
            onChange={handleInputChange}/>  
            </TableCell>

             <TableCell align="center">
             <Fab color="primary" aria-label="add" onClick={addClickHandle}  >
               Add 
             </Fab>
            </TableCell>

            </TableFooter>
          </Table>
        </TableContainer>
      </Paper>
          );
        
              }

export default ItemComponent