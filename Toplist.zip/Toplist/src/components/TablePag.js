import React from "react"
import ItemComponent from "./ItemComponent";

 const TablePag = () => {

const itemComponent = ItemComponent();
const tableItems = itemComponent.items;
console.log(tableItems);
    return(
        <TablePagination
rowsPerPageOptions={[10, 25, 100,200]}
component="div"
count={tableItems.length}
rowsPerPage={rowsPerPage}
page={page}
onPageChange={handleChangePage}
onRowsPerPageChange={handleChangeRowsPerPage} />

    )
   
}
export default TablePag




  
