import React, {Component} from "react";
import {BrowserRouter as Router,Switch, Route} from "react-router-dom";
import Header from "./Header";
import ItemList from "./ItemList";
import Admin from "./Admin";
import { EditItem } from "./Edit";

const App = ()=>{
 return( 

   <div>
      <Router>
         <Header/>
          <Switch>
            <Route path ="/" exact component={ItemList}/>
            <Route path ="/admin/edit" exact component={EditItem}/>
            <Route path ="/admin"component = {Admin}/>     
          </Switch>
      </Router>
        
    </div>

        )
    
}
export default App