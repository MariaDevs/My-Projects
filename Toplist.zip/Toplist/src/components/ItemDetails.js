import React from "react";

const ItemDetails = ()=>{
    return(
        <div>
            <h1>Item Details</h1>
        </div>
    )
}
export default ItemDetails