import React, {useEffect} from "react";
import ItemComponent from "./ItemComponent";
import axios from "axios";
import { useDispatch } from "react-redux";
import {setItems ,deleteItem, updateItem, ItemToDelete} from "../redux/actions/toplistActions";



const ItemList = ()=>{
    
    
    
    const dispatch = useDispatch();

const fetchItems = async ()=>{
const response = await axios.get("https://61d83b8ce6744d0017ba89e1.mockapi.io/api/v1/toplistItems").catch((err) => {
   console.log("Err", err);
}); 
dispatch(setItems(response.data)); 
};
useEffect(() => {fetchItems();
},[]);



    return(
        <div>
            <ItemComponent/>
        </div>
    )
     

    
}


    
         

export default ItemList