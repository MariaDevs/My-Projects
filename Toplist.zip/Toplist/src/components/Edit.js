import React from "react";
import { TextField,Box,Card,CardContent,Typography,CardActions,Button, Link } from "@material-ui/core";
import Header from "./Header";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";

export const EditItem = () =>{


  let history = useHistory;
  
  const updateClickHandle = () =>{

  }
  const bull = (
        <Box
          component="span"
          sx={{ display: 'inline-block', mx: '2px', transform: 'scale(0.8)' }}
        >
          •
        </Box>
      );
    return(
        <div>
       
        <Card sx={{ minWidth: 275 }}>
        <CardContent>
    <div>
  <TextField id="updateId" label="ID" variant="outlined" />
  <TextField id="updateBrand" label="Brand" variant="outlined" />
  <TextField id="updateOffer" label="Offer" variant="outlined" />
  <TextField id="updateTraffic" label="Tracking Link" variant="outlined" />
  <TextField id="updateCreated" label="Created At" variant="outlined" />
  <span>.............</span>
  <span marin-left="20">
  <Button variant="contained" color="primary" onClick={updateClickHandle()}>Update</Button>
  <span>......</span>
  <Button variant="contained" color="secondary" onClick={()=>history.push("/admin")}>Cancel</Button>
  </span>     
  </div>
         
        </CardContent>
       
      </Card>
      </div>
    );            
 
}


  
 
  
  
  
