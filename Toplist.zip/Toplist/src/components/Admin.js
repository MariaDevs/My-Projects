import React from "react";
import { Typography } from "@material-ui/core";
import ItemList from "./ItemList";



const Admin = ()=>{
    

    return(
        <div>
         <Typography color="textPrimary" variant ="h6">Admin</Typography>
            <ItemList/>       
        </div>
    )
}
export default Admin