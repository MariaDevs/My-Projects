import React from "react";
import { Typography, Breadcrumbs,Fab } from "@material-ui/core";




export default function Header() {
  return (
    <div>
      <Breadcrumbs aria-label="breadcrumb">
        <Typography color="textPrimary" variant ="h2">Kazoom Casino TopList</Typography>
       
        
      </Breadcrumbs>
    </div>
  );
}


